const express = require('express');
const { MongoClient, ObjectId } = require('mongodb');
const session = require('express-session');
const bcrypt = require('bcrypt');
const methodOverride = require('method-override');
const path = require('path');
const { log } = require('console');
const app = express();

const porta = 3002;
const urlMongo = 'mongodb://localhost:27017/';
const dbNameEconext = 'econext';
const collectionNameLoginEmpresa = 'LoginEmpresa';
const collectionNameLoginUsuario = 'LoginUsuario'
let NomeusuarioEmpresa;


app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(methodOverride('_method'));
app.use(express.static(__dirname + '/public'));


app.use(session({
    secret: 'segredo-super-seguro',
    resave: false,
    saveUninitialized: true,
}));




app.get('/paraempresas', (req, res) => {
    res.sendFile(__dirname + '/paraEmpresa.html');
});

app.get('/registroEmpresa', (req, res) => {
    res.sendFile(__dirname + '/registroEmpresa.html');
});

app.get('/loginEmpresa', (req, res) => {
    res.sendFile(__dirname + '/loginEmpresa.html');
});

app.get('/registroUsuario', (req, res) => {
    res.sendFile(__dirname + '/registroUsuario.html');
});

app.get('/loginUsuario', (req, res) => {
    res.sendFile(__dirname + '/loginUsuario.html');
});


app.post('/registroEmpresa', async (req, res) => {
    const cliente = new MongoClient(urlMongo, { useUnifiedTopology: true });
    try {
        await cliente.connect();
        const banco = cliente.db(dbNameEconext);
        const colecaoUsuarios = banco.collection(collectionNameLoginEmpresa);

        const usuarioExistente = await colecaoUsuarios.findOne({ usuario: req.body.usuario });

        if (usuarioExistente) {
            res.sendFile(__dirname + '/duplicataempresa.html');
        } else {
            const senhaCriptografada = await bcrypt.hash(req.body.senha, 10);
            await colecaoUsuarios.insertOne({
                usuario: req.body.usuario,
                senha: senhaCriptografada
            });
            res.sendFile(__dirname + '/sucessoempresa.html');
        }
    } catch (erro) {
        res.send('Erro ao registrar o usuário.');
    } finally {
        cliente.close();
    }
});


app.post('/loginEmpresa', async (req, res) => {
    const cliente = new MongoClient(urlMongo);
    try {
        await cliente.connect();
        const banco = cliente.db(dbNameEconext);
        const colecaoUsuarios = banco.collection(collectionNameLoginEmpresa);

        usuario = await colecaoUsuarios.findOne({ usuario: req.body.usuario });
        NomeusuarioEmpresa = await colecaoUsuarios.findOne({ usuario: req.body.usuario.usuario });


        if (usuario && await bcrypt.compare(req.body.senha, usuario.senha)) {

            req.session.usuario = req.body.usuario;
            req.session.usuarioId = usuario._id;
            NomeusuarioEmpresa = usuario.usuario;


            res.redirect('/homeempresa');
        } else {

            res.redirect('/erro');
        }
    } catch (erro) {
        res.send('Erro ao realizar login.');
    } finally {
        cliente.close();
    }

});

app.post('/registroUsuario', async (req, res) => {
    const cliente = new MongoClient(urlMongo);
    const usuario = req.body;

    try {

        const usuarioExistente = await cliente.db(dbNameEconext)
            .collection(collectionNameLoginUsuario)
            .findOne({ email: usuario.email });

        if (usuarioExistente) {
            return res.sendFile(__dirname + '/duplicatausuario.html');
        }

        const senhaCriptografada = await bcrypt.hash(usuario.senha, 10);
        usuario.senha = senhaCriptografada;

        await cliente.connect();
        const db = cliente.db(dbNameEconext);
        const colecaoUsuarios = db.collection(collectionNameLoginUsuario);

        await colecaoUsuarios.insertOne(usuario);


        res.sendFile(__dirname + '/sucessousuario.html');
    } catch (erro) {
        res.status(500).send('Erro ao registrar o usuário.');
    } finally {
        cliente.close();
    }
});

app.post('/loginUsuario', async (req, res) => {
    const cliente = new MongoClient(urlMongo);

    try {
        await cliente.connect();
        const banco = cliente.db(dbNameEconext);
        const colecaoUsuarios = banco.collection(collectionNameLoginUsuario);

        const usuario = await colecaoUsuarios.findOne({ email: req.body.email });


        if (usuario && await bcrypt.compare(req.body.senha, usuario.senha)) {

            req.session.email = usuario.email;
            req.session.emailId = usuario._id;


            res.redirect('/homeUsuario');
        } else {

            res.redirect('/erroo');
        }
    } catch (erro) {
        console.error(erro);
        res.status(500).send('Erro ao realizar login.');
    } finally {
        await cliente.close();
    }
});



app.get('/erro', (req, res) => {
    res.sendFile(__dirname + '/erro.html');
});
app.get('/erroo', (req, res) => {
    res.sendFile(__dirname + '/errousuario.html');
});

app.get('/sair', (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            return res.send('Erro ao sair!');
        }
        res.redirect('/');
    });
});


function protegerRota(req, res, proximo) {
    if (req.session.usuario) {
        proximo();
    } else {
        res.redirect('/loginEmpresa');
    }
}


function protegerRotaUser(req, res, proximo) {
    if (req.session.email) {
        proximo();
    } else {
        res.redirect('/loginUsuario');
    }
}


app.get('/', (req, res) => {
    res.sendFile(__dirname + '/ParaUsuario.html');
});

app.get('/adicionarvagas', protegerRota, (req, res) => {
    res.sendFile(__dirname + '/adicionarvagas.html');
});

app.get('/gerenciarvagas', protegerRota, (req, res) => {
    res.sendFile(__dirname + '/gerenciarvagas.html');
});

app.get('/vertalentos', protegerRota, (req, res) => {
    res.sendFile(__dirname + '/vertalentos.html');
});


app.get('/meusdados', protegerRotaUser, (req, res) => {
    res.sendFile(__dirname + '/meusdados.html');
});

app.get('/acessaria', protegerRotaUser, (req, res) => {
    res.sendFile(__dirname + '/acessaria.html');
});




app.post('/cadastro-vagas', protegerRota, async (req, res) => {
    const novavaga = req.body;
    const client = new MongoClient(urlMongo);

    try {
        await client.connect();
        const db = client.db(dbNameEconext);
        const collection = db.collection(NomeusuarioEmpresa);
        await collection.insertOne(novavaga);
        res.redirect('/gerenciarvagas');
    } catch (err) {
        console.error('Erro ao cadastrar a vaga:', err);
        res.status(500).send('Erro ao cadastrar a vaga.');
    } finally {
        client.close();
    }
});


app.get('/vagas', protegerRota, async (req, res) => {
    const client = new MongoClient(urlMongo);

    try {
        await client.connect();
        const db = client.db(dbNameEconext);
        const collection = db.collection(NomeusuarioEmpresa);
        const vagas = await collection.find({}).toArray();
        res.json(vagas);
    } catch (err) {
        console.error('Erro ao buscar vagas:', err);
        res.status(500).send('Erro ao buscar vagas.');
    } finally {
        client.close();
    }
});


app.get('/users', protegerRota, async (req, res) => {
    const client = new MongoClient(urlMongo);

    try {
        await client.connect();
        const db = client.db(dbNameEconext);
        const collection = db.collection("LoginUsuario");
        const users = await collection.find({}).toArray();
        res.json(users);
    } catch (err) {
        console.error('Erro ao buscar usuario:', err);
        res.status(500).send('Erro ao buscar usuario.');
    } finally {
        client.close();
    }
});

app.get('/vaga', async (req, res) => {
    const { titulo } = req.query;
    const client = new MongoClient(urlMongo);

    try {
        await client.connect();
        const db = client.db(dbNameEconext);
        const collection = db.collection(NomeusuarioEmpresa);

        let query = {};


        if (titulo) {
            console.log('Parâmetro recebido para título:', titulo);
            if (typeof titulo !== 'string') {
                return res.status(400).send('Parâmetro "titulo" deve ser uma string.');
            }
            query.titulo = { $regex: new RegExp(titulo, 'i') };
        }


        const vagas = await collection.find(query).toArray();

        if (vagas.length === 0) {
            return res.status(404).send('Nenhuma vaga encontrada.');
        }

        res.json(vagas);
    } catch (err) {
        console.error('Erro ao buscar a vaga:', err);
        res.status(500).send('Erro ao buscar a vaga. Por favor, tente novamente mais tarde.');
    } finally {
        await client.close();
    }
});


app.get('/vaga/:id', async (req, res) => {
    const { id } = req.params;


    const client = new MongoClient(urlMongo);

    try {
        await client.connect();
        const db = client.db(dbNameEconext);
        const collection = db.collection(NomeusuarioEmpresa);


        const vaga = await collection.findOne({ _id: new ObjectId(id) });

        if (!vaga) {
            return res.status(404).send('vaga não encontrado');
        }

        res.json(vaga);
    } catch (err) {
        console.error('Erro ao buscar o vaga:', err);
        console.log(NomeusuarioEmpresa)
        res.status(500).send('Erro ao buscar o vaga. Por favor, tente novamente mais tarde.');
    } finally {
        client.close();
    }
});

app.get('/meudado', protegerRotaUser, async (req, res) => {
    const cliente = new MongoClient(urlMongo);
    try {
        await cliente.connect();
        const banco = cliente.db(dbNameEconext);
        const colecaoUsuarios = banco.collection(collectionNameLoginUsuario); // Corrigido para uso de aspas.

        const usuario = await colecaoUsuarios.findOne({ _id: new ObjectId(req.session.emailId) }); // Busca o ID da sessão.

        if (usuario) {
            res.json(usuario);
        } else {
            res.status(404).send('Usuário não encontrado.');
        }
    } catch (erro) {
        console.error('Erro ao buscar dados do usuário:', erro);
        res.status(500).send('Erro ao buscar dados do usuário.');
    } finally {
        await cliente.close();
    }
});



app.get('/atualizar-vaga', (req, res) => {
    res.sendFile(__dirname + '/atualizar-vaga.html');
});

app.post('/atualizar-vaga', protegerRota, async (req, res) => {
    const { id, titulo, resumo, tipo, nivel } = req.body;
    const client = new MongoClient(urlMongo);

    try {
        await client.connect();
        const db = client.db(dbNameEconext);
        const collection = db.collection(NomeusuarioEmpresa);
        const result = await collection.updateOne(
            { _id: new ObjectId(id) },
            { $set: { titulo, resumo, tipo, nivel } }
        );

        if (result.matchedCount > 0) {
            res.redirect('/gerenciarvagas');
        } else {
            res.status(404).send('Vaga não encontrada.');
        }
    } catch (err) {
        console.error('Erro ao atualizar vaga:', err);
        res.status(500).send('Erro ao atualizar vaga.');
    } finally {
        client.close();
    }
});


app.post('/atualizar-dado', protegerRotaUser, async (req, res) => {
    const { id, nome, cel, tipo, nivel, date } = req.body;
    const client = new MongoClient(urlMongo);

    try {
        await client.connect();
        const db = client.db(dbNameEconext);
        const collection = db.collection(collectionNameLoginUsuario);
        const result = await collection.updateOne(
            { _id: new ObjectId(id) },
            { $set: { nome, cel, tipo, nivel, date } }
        );

        if (result.matchedCount > 0) {
            res.redirect('/meusdados');
        } else {
            res.status(404).send('usuario não encontrada.');
        }
    } catch (err) {
        console.error('Erro ao atualizar usuario:', err);
        res.status(500).send('Erro ao atualizar usuario.');
    } finally {
        client.close();
    }
});



app.post('/deletar-vaga', async (req, res) => {
    const { id } = req.body;
    const client = new MongoClient(urlMongo);

    try {
        await client.connect();
        const db = client.db(dbNameEconext);
        const collection = db.collection(NomeusuarioEmpresa);
        const result = await collection.deleteOne({ _id: new ObjectId(id) });

        if (result.deletedCount > 0) {
            res.redirect('/gerenciarvagas');
        } else {
            res.status(404).send('Vaga não encontrada.');
        }
    } catch (err) {
        console.error('Erro ao deletar a vaga:', err);
        res.status(500).send('Erro ao deletar a vaga.');
    } finally {
        client.close();
    }
});


app.get('/homeEmpresa', protegerRota, (req, res) => {
    res.sendFile(__dirname + '/homeEmpresa.html');
});

app.get('/homeUsuario', protegerRotaUser, (req, res) => {
    res.sendFile(__dirname + '/homeUsuario.html');
});

app.get('/', (req, res) => {
    res.sendFile(__dirname + '/ParaUsuario.html');
});

app.listen(porta, () => {
    console.log(`Servidor rodando na porta http://localhost:${porta}/`);
});
